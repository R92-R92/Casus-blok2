from flask import Flask, render_template, request, redirect, session, url_for
from Controllers.DatabaseController import DatabaseController
from Controllers.PlanningController import PlanningController
from auth import login_required
from forms import LoginForm

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Nodig voor sessiebeheer

db = DatabaseController()


def get_user_by_email(email):
    db = DatabaseController()  # Open een nieuwe databaseverbinding
    users = db.fetch_by_condition("Gebruiker", {"Email": email})
    return users[0] if users else None


@app.route('/')
@app.route('/index')
def index() :
    return render_template('index.html')

@app.route('/Login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit() and request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = get_user_by_email(email)

        if user and user[5] == password:  # user[4] is het wachtwoord
            session['user_id'] = user[0]  # user[0] is de ID
            session['role'] = user[4]  # user[5] is de rol_id
            return redirect('/dashboard')

        return "Ongeldige login!", 403

    return render_template('login.html', form=form)


@app.route('/dashboard')
@login_required()
def dashboard():
    return render_template('base.html')


@app.route('/beheerder')
@login_required(role=3)
def beheerder_panel():
    return render_template('base.html')


@app.route('/admin')
@login_required(role=2)
def admin_panel():
    return "Welkom in het admin panel!"


@app.route('/docent')
@login_required(role=1)
def docent_panel():
    return "Welkom in het docenten paneel!"


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')


def get_all_users():
    return db.fetch_all("Gebruiker")


def get_user_by_id(user_id):
    users = db.fetch_by_condition("Gebruiker", {"id": user_id})
    return users[0] if users else None


@app.route('/gebruikers')
@login_required(role=2)
def gebruikers_overzicht():
    gebruikers = get_all_users()
    return render_template('gebruikers.html', gebruikers=gebruikers)


@app.route('/gebruikers/toevoegen', methods=['GET', 'POST'])
@login_required(role=2)
def gebruikers_toevoegen():
    if request.method == 'POST':
        naam = request.form['naam']
        email = request.form['email']
        rol = int(request.form['rol'])

        if session['role'] == 2 and rol >= 2:
            return "Geen toestemming om deze rol aan te maken!", 403

        db.insert("Gebruiker", {"Voornaam": naam, "Email": email, "Rol_id": rol, "Wachtwoord": "default"})
        return redirect('/gebruikers')

    return render_template('gebruiker_toevoegen.html')


@app.route('/gebruikers/verwijderen/<int:id>')
@login_required(role=2)
def gebruikers_verwijderen(id):
    gebruiker = get_user_by_id(id)
    if not gebruiker:
        return "Gebruiker niet gevonden", 404

    if session['role'] == 2 and gebruiker[5] >= 2:
        return "Geen toestemming om deze gebruiker te verwijderen!", 403

    db.delete("Gebruiker", {"id": id})
    return redirect('/gebruikers')


@app.route('/gebruikers/blokkeren/<int:id>')
@login_required(role=2)
def gebruikers_blokkeren(id):
    gebruiker = get_user_by_id(id)
    if not gebruiker:
        return "Gebruiker niet gevonden", 404

    if session['role'] == 2 and gebruiker[5] >= 2:
        return "Geen toestemming om deze gebruiker te blokkeren!", 403

    db.update("Gebruiker", {"Rol_id": -1}, {"id": id})
    return redirect('/gebruikers')


planning_controller = PlanningController()


@app.route('/planning')
@login_required()
def planning_overzicht():
    reserveringen = planning_controller.get_all_reservations()
    return render_template('planning.html', reserveringen=reserveringen)


@app.route('/planning/toevoegen', methods=['GET', 'POST'])
@login_required(role=1)  # Alleen docenten en hoger mogen reserveringen maken
def planning_toevoegen():
    if request.method == 'POST':
        datum = request.form['datum']
        tijd = request.form['tijd']
        beschrijving = request.form['beschrijving']
        gebruiker_id = session['user_id']  # De ingelogde gebruiker

        planning_controller.create_reservation(gebruiker_id, datum, tijd, beschrijving)
        return redirect('/planning')

    return render_template('planning_toevoegen.html')


@app.route('/planning/wijzigen/<int:id>', methods=['GET', 'POST'])
@login_required(role=2)  # Alleen admins en beheerders mogen reserveringen wijzigen
def planning_wijzigen(id):
    reservering = planning_controller.get_reservation_by_id(id)
    if not reservering:
        return "Reservering niet gevonden", 404

    if request.method == 'POST':
        datum = request.form['datum']
        tijd = request.form['tijd']
        beschrijving = request.form['beschrijving']

        planning_controller.update_reservation(id, datum, tijd, beschrijving)
        return redirect('/planning')

    return render_template('planning_wijzigen.html', reservering=reservering[0])


@app.route('/planning/verwijderen/<int:id>')
@login_required(role=2)  # Alleen admins en beheerders mogen verwijderen
def planning_verwijderen(id):
    reservering = planning_controller.get_reservation_by_id(id)
    if not reservering:
        return "Reservering niet gevonden", 404

    planning_controller.delete_reservation(id)
    return redirect('/planning')


# ------------------------------------------------------------------------------------------------------- #
@app.route('/planning/docent')
@login_required(role=1)  # Alleen docenten en hoger
def planning_docent():
    reserveringen = planning_controller.get_all_reservations()
    return render_template('planning_docent.html', reserveringen=reserveringen)


@app.route('/planning/docent/toevoegen', methods=['GET', 'POST'])
@login_required(role=1)  # Alleen docenten mogen reserveringen maken
def planning_docent_toevoegen():
    if request.method == 'POST':
        datum = request.form['datum']
        tijd = request.form['tijd']
        beschrijving = request.form['beschrijving']
        gebruiker_id = session['user_id']  # De ingelogde docent

        planning_controller.create_reservation(gebruiker_id, datum, tijd, beschrijving)
        return redirect('/planning/docent')

    return render_template('planning_docent_toevoegen.html')


@app.route('/planning/gebruiker')
@login_required(role=0)  # Alleen gebruikers en hoger
def planning_gebruiker():
    reserveringen = planning_controller.get_all_reservations()
    return render_template('planning_gebruiker.html', reserveringen=reserveringen)

